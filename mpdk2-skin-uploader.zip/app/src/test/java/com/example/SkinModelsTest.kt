package com.example

import com.example.model.AnimationMode
import com.example.model.SkinItem
import com.example.model.SkinNameFormatter
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SkinModelsTest {

  @Test
  fun skinNameFormatter_formatsToSnakeCaseWithoutExtension() {
    assertEquals("closed_hihat_bronze", SkinNameFormatter.finalizeName("Closed Hihat Bronze.png"))
    assertEquals("latar_panggung_konser", SkinNameFormatter.finalizeName("Latar-Panggung Konser.JPG"))
    assertEquals("snare_custom_01", SkinNameFormatter.finalizeName("  Snare   Custom!! 01.webp "))
    assertEquals("hi_hat_", SkinNameFormatter.formatWhileTyping("Hi Hat "))
  }

  @Test
  fun animationModes_exposeExactRequestedCategories() {
    assertEquals(
      listOf("Studio", "Konser", "Akustik", "Metal", "Custom Pad"),
      AnimationMode.DEFAULT.categories,
    )
    assertEquals(
      listOf(
        "Snare",
        "Tom 1",
        "Tom 2",
        "Floor Tom",
        "Crash Left",
        "Splash",
        "Ride",
        "Ride Bell",
        "China",
        "Crash Right",
        "Closed Hi-Hat",
        "Pedal Open Hi-Hat",
        "Pedal Kick Bass",
        "Backgrounds",
      ),
      AnimationMode.ANIM2.categories,
    )
  }

  @Test
  fun moshiSerialization_matchesExactSkinsJsonStructure() {
    val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
    val listType = Types.newParameterizedType(List::class.java, SkinItem::class.java)
    val adapter = moshi.adapter<List<SkinItem>>(listType).indent("  ")

    val item = SkinItem(
      mode = "anim2",
      category = "Closed Hi-Hat",
      name = "closed_hihat_bronze",
      format = "PNG (Transparan)",
      shape = "3D Component Render",
      image = "assets/anim2/closed_hihat_bronze_1234.png",
    )

    val json = adapter.toJson(listOf(item))
    assertTrue(json.contains("\"mode\": \"anim2\""))
    assertTrue(json.contains("\"category\": \"Closed Hi-Hat\""))
    assertTrue(json.contains("\"name\": \"closed_hihat_bronze\""))
    assertTrue(json.contains("\"format\": \"PNG (Transparan)\""))
    assertTrue(json.contains("\"shape\": \"3D Component Render\""))
    assertTrue(json.contains("\"image\": \"assets/anim2/closed_hihat_bronze_1234.png\""))
    assertFalse(json.contains("\\/"))

    val parsed = adapter.fromJson(json)
    assertEquals(listOf(item), parsed)
  }
}
