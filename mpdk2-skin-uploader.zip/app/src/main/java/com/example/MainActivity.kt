package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.MainScreen
import com.example.ui.SkinsViewModel
import com.example.ui.theme.Mpdk2UploaderTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      Mpdk2UploaderTheme {
        val skinsViewModel: SkinsViewModel = viewModel(
          factory = SkinsViewModel.provideFactory(application),
        )
        MainScreen(viewModel = skinsViewModel)
      }
    }
  }
}
