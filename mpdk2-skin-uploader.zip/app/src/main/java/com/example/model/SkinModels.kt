package com.example.model

import com.squareup.moshi.JsonClass

enum class AnimationMode(
  val id: String,
  val displayLabel: String,
  val shortLabel: String,
  val categories: List<String>,
) {
  DEFAULT(
    id = "default",
    displayLabel = "Mode Default (1 Set)",
    shortLabel = "default",
    categories = listOf("Studio", "Konser", "Akustik", "Metal", "Custom Pad"),
  ),
  ANIM2(
    id = "anim2",
    displayLabel = "Mode Animasi 2 (3D)",
    shortLabel = "anim2",
    categories = listOf(
      "Snare",
      "Tom 1",
      "Tom 2",
      "Floor Tom",
      "Crash Left",
      "Splash",
      "Ride",
      "Ride Bell",
      "China",
      "Crash Right",
      "Closed Hi-Hat",
      "Pedal Open Hi-Hat",
      "Pedal Kick Bass",
      "Backgrounds",
    ),
  );

  companion object {
    fun fromId(id: String): AnimationMode =
      entries.firstOrNull { it.id.equals(id, ignoreCase = true) } ?: DEFAULT
  }
}

object SkinOptions {
  val fileFormats = listOf(
    "PNG (Transparan)",
    "JPG (High-Res)",
    "JPG (Full Set)",
  )

  val shapePresets = listOf(
    "3D Component Render",
    "Latar Panggung 3D",
    "1 Set Drum Utuh",
  )

  fun defaultExtensionForFormat(format: String): String =
    if (format.startsWith("PNG", ignoreCase = true)) "png" else "jpg"
}

@JsonClass(generateAdapter = true)
data class SkinItem(
  val mode: String,
  val category: String,
  val name: String,
  val format: String,
  val shape: String,
  val image: String,
)

object SkinNameFormatter {
  private val extensionRegex = Regex("\\.(png|jpe?g|webp|gif)$", RegexOption.IGNORE_CASE)
  private val separatorRegex = Regex("[\\s\\-.]+")
  private val invalidCharsRegex = Regex("[^a-z0-9_]")
  private val multipleUnderscoresRegex = Regex("_+")

  /**
   * Formats raw input into lowercase snake_case without spaces or image file extensions.
   * Preserves trailing underscore while typing so users can type multi-word names naturally.
   */
  fun formatWhileTyping(raw: String): String {
    val noExt = raw.trimStart().replace(extensionRegex, "")
    val lower = noExt.lowercase()
    val replacedSpaces = lower.replace(separatorRegex, "_")
    val cleaned = replacedSpaces.replace(invalidCharsRegex, "")
    return cleaned.replace(multipleUnderscoresRegex, "_")
  }

  /**
   * Final sanitized name with leading/trailing underscores trimmed.
   */
  fun finalizeName(raw: String): String =
    formatWhileTyping(raw.trim()).trim('_')
}
