package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "mpdk2_admin_prefs")

data class StoredAuthConfig(
  val token: String = "",
  val username: String = "",
)

class TokenStore(private val context: Context) {
  private object Keys {
    val GITHUB_PAT = stringPreferencesKey("github_pat")
    val GITHUB_USERNAME = stringPreferencesKey("github_username")
  }

  val authConfigFlow: Flow<StoredAuthConfig> =
    context.dataStore.data.map { prefs ->
      StoredAuthConfig(
        token = prefs[Keys.GITHUB_PAT].orEmpty(),
        username = prefs[Keys.GITHUB_USERNAME].orEmpty(),
      )
    }

  suspend fun saveToken(token: String, username: String = "") {
    context.dataStore.edit { prefs ->
      prefs[Keys.GITHUB_PAT] = token.trim()
      if (username.isNotBlank()) {
        prefs[Keys.GITHUB_USERNAME] = username.trim()
      }
    }
  }

  suspend fun updateUsername(username: String) {
    context.dataStore.edit { prefs ->
      prefs[Keys.GITHUB_USERNAME] = username.trim()
    }
  }

  suspend fun clearToken() {
    context.dataStore.edit { prefs ->
      prefs.remove(Keys.GITHUB_PAT)
      prefs.remove(Keys.GITHUB_USERNAME)
    }
  }
}
