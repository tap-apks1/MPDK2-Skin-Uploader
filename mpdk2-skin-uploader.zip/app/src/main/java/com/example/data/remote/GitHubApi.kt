package com.example.data.remote

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.HTTP
import retrofit2.http.Header
import retrofit2.http.PUT
import retrofit2.http.Path
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

object GitHubRepoConfig {
  const val OWNER = "tap-apks1"
  const val REPO = "mpdk2-skins"
  const val BRANCH = "main"
  const val SKINS_JSON_PATH = "skins.json"
  const val BASE_API_URL = "https://api.github.com/"

  fun rawUrl(relativePath: String): String {
    val clean = relativePath.trimStart('/')
    return "https://raw.githubusercontent.com/$OWNER/$REPO/$BRANCH/$clean"
  }
}

@JsonClass(generateAdapter = true)
data class GitHubContentResponse(
  val name: String = "",
  val path: String = "",
  val sha: String = "",
  val content: String? = null,
  val encoding: String? = null,
)

@JsonClass(generateAdapter = true)
data class GitHubPutFileRequest(
  val message: String,
  val content: String,
  val branch: String,
  val sha: String? = null,
)

@JsonClass(generateAdapter = true)
data class GitHubPutFileResponse(
  val content: GitHubContentSummary? = null,
)

@JsonClass(generateAdapter = true)
data class GitHubContentSummary(
  val name: String = "",
  val path: String = "",
  val sha: String = "",
)

@JsonClass(generateAdapter = true)
data class GitHubDeleteFileRequest(
  val message: String,
  val sha: String,
  val branch: String,
)

@JsonClass(generateAdapter = true)
data class GitHubUserResponse(
  val login: String = "",
  @Json(name = "avatar_url") val avatarUrl: String = "",
)

@JsonClass(generateAdapter = true)
data class GitHubErrorResponse(
  val message: String = "",
)

interface GitHubApiService {
  @GET("user")
  suspend fun getCurrentUser(
    @Header("Authorization") authorization: String,
    @Header("Accept") accept: String = ACCEPT_HEADER,
    @Header("X-GitHub-Api-Version") apiVersion: String = API_VERSION,
  ): Response<GitHubUserResponse>

  @GET("repos/{owner}/{repo}/contents/{path}")
  suspend fun getFileContent(
    @Header("Authorization") authorization: String,
    @Path("owner") owner: String,
    @Path("repo") repo: String,
    @Path("path", encoded = true) path: String,
    @Query("ref") branch: String,
    @Header("Cache-Control") cacheControl: String = "no-cache",
    @Header("Accept") accept: String = ACCEPT_HEADER,
    @Header("X-GitHub-Api-Version") apiVersion: String = API_VERSION,
  ): Response<GitHubContentResponse>

  @PUT("repos/{owner}/{repo}/contents/{path}")
  suspend fun putFileContent(
    @Header("Authorization") authorization: String,
    @Path("owner") owner: String,
    @Path("repo") repo: String,
    @Path("path", encoded = true) path: String,
    @Body body: GitHubPutFileRequest,
    @Header("Accept") accept: String = ACCEPT_HEADER,
    @Header("X-GitHub-Api-Version") apiVersion: String = API_VERSION,
  ): Response<GitHubPutFileResponse>

  @HTTP(method = "DELETE", path = "repos/{owner}/{repo}/contents/{path}", hasBody = true)
  suspend fun deleteFileContent(
    @Header("Authorization") authorization: String,
    @Path("owner") owner: String,
    @Path("repo") repo: String,
    @Path("path", encoded = true) path: String,
    @Body body: GitHubDeleteFileRequest,
    @Header("Accept") accept: String = ACCEPT_HEADER,
    @Header("X-GitHub-Api-Version") apiVersion: String = API_VERSION,
  ): Response<Unit>

  companion object {
    private const val ACCEPT_HEADER = "application/vnd.github+json"
    private const val API_VERSION = "2022-11-28"

    fun create(moshi: Moshi): GitHubApiService {
      val logger = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BASIC
      }
      val client = OkHttpClient.Builder()
        .addInterceptor(logger)
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

      return Retrofit.Builder()
        .baseUrl(GitHubRepoConfig.BASE_API_URL)
        .client(client)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()
        .create(GitHubApiService::class.java)
    }
  }
}
