package com.example.data.repository

import android.util.Base64
import com.example.data.remote.GitHubApiService
import com.example.data.remote.GitHubDeleteFileRequest
import com.example.data.remote.GitHubErrorResponse
import com.example.data.remote.GitHubPutFileRequest
import com.example.data.remote.GitHubRepoConfig
import com.example.model.AnimationMode
import com.example.model.SkinItem
import com.squareup.moshi.JsonAdapter
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import retrofit2.Response
import java.nio.charset.StandardCharsets

data class SkinsFetchResult(
  val items: List<SkinItem>,
  val skinsJsonSha: String?,
)

class GitHubSkinsRepository(
  private val api: GitHubApiService,
  private val moshi: Moshi,
) {
  private val listType = Types.newParameterizedType(List::class.java, SkinItem::class.java)
  private val skinListAdapter: JsonAdapter<List<SkinItem>> = moshi.adapter<List<SkinItem>>(listType).indent("  ")
  private val errorAdapter: JsonAdapter<GitHubErrorResponse> = moshi.adapter(GitHubErrorResponse::class.java)

  private fun authHeader(token: String): String = "Bearer ${token.trim()}"

  suspend fun verifyToken(token: String): Result<String> = withContext(Dispatchers.IO) {
    runCatching {
      val cleanToken = token.trim()
      require(cleanToken.isNotBlank()) { "Token GitHub tidak boleh kosong." }
      val resp = api.getCurrentUser(authorization = authHeader(cleanToken))
      if (!resp.isSuccessful) {
        throw IllegalStateException(formatHttpError(resp, "memverifikasi token"))
      }
      resp.body()?.login?.ifBlank { "GitHub User" } ?: "GitHub User"
    }
  }

  suspend fun fetchSkins(token: String? = null): Result<SkinsFetchResult> = withContext(Dispatchers.IO) {
    runCatching {
      val cleanToken = token?.trim().orEmpty()
      if (cleanToken.isBlank()) {
        throw IllegalStateException("Masukkan Token GitHub (PAT) terlebih dahulu.")
      }
      fetchSkinsInternal(cleanToken)
    }
  }

  private suspend fun fetchSkinsInternal(token: String): SkinsFetchResult {
    val resp = api.getFileContent(
      authorization = authHeader(token),
      owner = GitHubRepoConfig.OWNER,
      repo = GitHubRepoConfig.REPO,
      path = GitHubRepoConfig.SKINS_JSON_PATH,
      branch = GitHubRepoConfig.BRANCH,
    )

    if (resp.code() == 404) {
      return SkinsFetchResult(items = emptyList(), skinsJsonSha = null)
    }
    if (!resp.isSuccessful) {
      throw IllegalStateException(formatHttpError(resp, "mengambil skins.json"))
    }

    val body = resp.body() ?: return SkinsFetchResult(items = emptyList(), skinsJsonSha = null)
    val encoded = body.content.orEmpty()
    if (encoded.isBlank()) {
      return SkinsFetchResult(items = emptyList(), skinsJsonSha = body.sha.ifBlank { null })
    }

    val decodedJson = decodeBase64Utf8(encoded)
    val items = if (decodedJson.isBlank()) {
      emptyList()
    } else {
      skinListAdapter.fromJson(decodedJson) ?: emptyList()
    }
    return SkinsFetchResult(
      items = items,
      skinsJsonSha = body.sha.ifBlank { null },
    )
  }

  suspend fun uploadSkin(
    token: String,
    mode: AnimationMode,
    category: String,
    skinName: String,
    format: String,
    shape: String,
    imageBytes: ByteArray,
    fileExtension: String,
    onProgress: (String) -> Unit,
  ): Result<List<SkinItem>> = withContext(Dispatchers.IO) {
    runCatching {
      val cleanToken = token.trim()
      require(cleanToken.isNotBlank()) { "Token GitHub (PAT) belum diisi." }
      require(skinName.isNotBlank()) { "Judul nama skin tidak boleh kosong." }
      require(imageBytes.isNotEmpty()) { "File gambar kosong atau tidak dapat dibaca." }

      val timestamp = System.currentTimeMillis() / 1000L
      val cleanExt = fileExtension.trimStart('.').lowercase().ifBlank { "png" }
      val imagePath = "assets/${mode.id}/${skinName}_${timestamp}.$cleanExt"

      onProgress("1/3 Mengunggah gambar ke $imagePath...")
      val imageBase64 = Base64.encodeToString(imageBytes, Base64.NO_WRAP)
      val putImageResp = api.putFileContent(
        authorization = authHeader(cleanToken),
        owner = GitHubRepoConfig.OWNER,
        repo = GitHubRepoConfig.REPO,
        path = imagePath,
        body = GitHubPutFileRequest(
          message = "Upload skin asset: $skinName ($category)",
          content = imageBase64,
          branch = GitHubRepoConfig.BRANCH,
        ),
      )
      if (!putImageResp.isSuccessful) {
        throw IllegalStateException(formatHttpError(putImageResp, "mengunggah gambar ke $imagePath"))
      }

      onProgress("2/3 Mengambil skins.json terbaru...")
      val current = fetchSkinsInternal(cleanToken)

      val newItem = SkinItem(
        mode = mode.id,
        category = category,
        name = skinName,
        format = format,
        shape = shape.trim(),
        image = imagePath,
      )
      val updatedList = listOf(newItem) + current.items
      val updatedJson = skinListAdapter.toJson(updatedList) + "\n"
      val jsonBase64 = Base64.encodeToString(updatedJson.toByteArray(StandardCharsets.UTF_8), Base64.NO_WRAP)

      onProgress("3/3 Memperbarui & commit skins.json...")
      val putJsonResp = api.putFileContent(
        authorization = authHeader(cleanToken),
        owner = GitHubRepoConfig.OWNER,
        repo = GitHubRepoConfig.REPO,
        path = GitHubRepoConfig.SKINS_JSON_PATH,
        body = GitHubPutFileRequest(
          message = "Add $skinName to skins.json",
          content = jsonBase64,
          branch = GitHubRepoConfig.BRANCH,
          sha = current.skinsJsonSha,
        ),
      )
      if (!putJsonResp.isSuccessful) {
        throw IllegalStateException(formatHttpError(putJsonResp, "memperbarui skins.json"))
      }

      updatedList
    }
  }

  suspend fun deleteSkin(
    token: String,
    item: SkinItem,
    onProgress: (String) -> Unit,
  ): Result<List<SkinItem>> = withContext(Dispatchers.IO) {
    runCatching {
      val cleanToken = token.trim()
      require(cleanToken.isNotBlank()) { "Token GitHub (PAT) belum diisi." }

      onProgress("1/3 Mengambil skins.json terbaru...")
      val current = fetchSkinsInternal(cleanToken)
      val updatedList = current.items.filterNot { existing ->
        existing.image == item.image && existing.name == item.name
      }

      val updatedJson = skinListAdapter.toJson(updatedList) + "\n"
      val jsonBase64 = Base64.encodeToString(updatedJson.toByteArray(StandardCharsets.UTF_8), Base64.NO_WRAP)

      onProgress("2/3 Menghapus entri dari skins.json...")
      val putJsonResp = api.putFileContent(
        authorization = authHeader(cleanToken),
        owner = GitHubRepoConfig.OWNER,
        repo = GitHubRepoConfig.REPO,
        path = GitHubRepoConfig.SKINS_JSON_PATH,
        body = GitHubPutFileRequest(
          message = "Remove ${item.name} from skins.json",
          content = jsonBase64,
          branch = GitHubRepoConfig.BRANCH,
          sha = current.skinsJsonSha,
        ),
      )
      if (!putJsonResp.isSuccessful) {
        throw IllegalStateException(formatHttpError(putJsonResp, "memperbarui skins.json"))
      }

      val imagePath = item.image.trimStart('/')
      if (imagePath.isNotBlank()) {
        onProgress("3/3 Menghapus file gambar $imagePath...")
        val fileMetaResp = api.getFileContent(
          authorization = authHeader(cleanToken),
          owner = GitHubRepoConfig.OWNER,
          repo = GitHubRepoConfig.REPO,
          path = imagePath,
          branch = GitHubRepoConfig.BRANCH,
        )
        if (fileMetaResp.isSuccessful) {
          val fileSha = fileMetaResp.body()?.sha.orEmpty()
          if (fileSha.isNotBlank()) {
            val deleteResp = api.deleteFileContent(
              authorization = authHeader(cleanToken),
              owner = GitHubRepoConfig.OWNER,
              repo = GitHubRepoConfig.REPO,
              path = imagePath,
              body = GitHubDeleteFileRequest(
                message = "Delete skin asset: ${item.name}",
                sha = fileSha,
                branch = GitHubRepoConfig.BRANCH,
              ),
            )
            if (!deleteResp.isSuccessful && deleteResp.code() != 404) {
              throw IllegalStateException(formatHttpError(deleteResp, "menghapus file gambar $imagePath"))
            }
          }
        } else if (fileMetaResp.code() != 404) {
          throw IllegalStateException(formatHttpError(fileMetaResp, "mengecek file gambar $imagePath"))
        }
      }

      updatedList
    }
  }

  private fun decodeBase64Utf8(rawBase64: String): String {
    val cleanBase64 = rawBase64.replace("\n", "").replace("\r", "").trim()
    val bytes = Base64.decode(cleanBase64, Base64.DEFAULT)
    return String(bytes, StandardCharsets.UTF_8)
  }

  private fun formatHttpError(response: Response<*>, action: String): String {
    val code = response.code()
    val rawErr = runCatching { response.errorBody()?.string() }.getOrNull().orEmpty()
    val ghMessage = runCatching {
      if (rawErr.isNotBlank()) errorAdapter.fromJson(rawErr)?.message else null
    }.getOrNull().orEmpty()

    return when (code) {
      401 -> "Token GitHub tidak valid atau kedaluwarsa (HTTP 401) saat $action."
      403 -> "Akses ditolak (HTTP 403) saat $action. Pastikan PAT memiliki izin repo (Contents: Read & Write)."
      404 -> "Repositori ${GitHubRepoConfig.OWNER}/${GitHubRepoConfig.REPO} atau file tidak ditemukan (HTTP 404) saat $action."
      409 -> "Konflik versi file di GitHub (HTTP 409) saat $action. Silakan muat ulang dan coba lagi."
      422 -> "Data tidak valid oleh GitHub (HTTP 422) saat $action. ${ghMessage}".trim()
      else -> "Gagal $action (HTTP $code). ${ghMessage}".trim()
    }
  }
}
