package com.example.ui.components

import android.net.Uri
import android.text.format.Formatter
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.R
import com.example.model.AnimationMode
import com.example.model.SkinOptions
import com.example.ui.SkinsUiState
import com.example.ui.theme.JetBrainsMonoFamily

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UploadSkinFormCard(
  state: SkinsUiState,
  onSkinNameChanged: (String) -> Unit,
  onModeSelected: (AnimationMode) -> Unit,
  onCategorySelected: (String) -> Unit,
  onFormatSelected: (String) -> Unit,
  onShapeInputChanged: (String) -> Unit,
  onImageSelected: (Uri?) -> Unit,
  onClearImage: () -> Unit,
  onUploadClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  val photoPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickVisualMedia(),
    onResult = onImageSelected,
  )

  var categoryDropdownExpanded by remember { mutableStateOf(false) }
  var formatDropdownExpanded by remember { mutableStateOf(false) }
  var showShapeInfoPreview by remember { mutableStateOf(false) }

  Card(
    modifier = modifier.fillMaxWidth(),
    shape = MaterialTheme.shapes.large,
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(18.dp),
    ) {
      // Section Title
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Surface(
          shape = RoundedCornerShape(10.dp),
          color = MaterialTheme.colorScheme.primaryContainer,
          modifier = Modifier.size(36.dp),
        ) {
          Icon(
            imageVector = Icons.Filled.CloudUpload,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(8.dp),
          )
        }
        Column {
          Text(
            text = stringResource(R.string.section_upload_form),
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onSurface,
          )
          Text(
            text = "Upload gambar aset & update skins.json otomatis",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      }

      // 1. Judul Nama Skin
      Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(
          text = stringResource(R.string.label_skin_name),
          style = MaterialTheme.typography.titleSmall,
          color = MaterialTheme.colorScheme.onSurface,
        )
        OutlinedTextField(
          value = state.skinNameInput,
          onValueChange = onSkinNameChanged,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("skin_name_input"),
          placeholder = {
            Text(
              text = stringResource(R.string.hint_skin_name),
              fontFamily = JetBrainsMonoFamily,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
          },
          singleLine = true,
          trailingIcon = {
            if (state.skinNameInput.isNotEmpty()) {
              IconButton(onClick = { onSkinNameChanged("") }) {
                Icon(
                  imageVector = Icons.Filled.Close,
                  contentDescription = "Hapus nama skin",
                )
              }
            }
          },
          supportingText = {
            Text(
              text = "Path: ${state.previewTargetPath}",
              fontFamily = JetBrainsMonoFamily,
              color = MaterialTheme.colorScheme.secondary,
            )
          },
          shape = MaterialTheme.shapes.small,
        )
      }

      // 2. Mode Animasi (2 Tombol)
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
          text = stringResource(R.string.label_animation_mode),
          style = MaterialTheme.typography.titleSmall,
          color = MaterialTheme.colorScheme.onSurface,
        )
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          ModeSelectionButton(
            mode = AnimationMode.DEFAULT,
            selected = state.selectedMode == AnimationMode.DEFAULT,
            onClick = { onModeSelected(AnimationMode.DEFAULT) },
            modifier = Modifier
              .weight(1f)
              .testTag("mode_default_button"),
          )
          ModeSelectionButton(
            mode = AnimationMode.ANIM2,
            selected = state.selectedMode == AnimationMode.ANIM2,
            onClick = { onModeSelected(AnimationMode.ANIM2) },
            modifier = Modifier
              .weight(1f)
              .testTag("mode_anim2_button"),
          )
        }
      }

      // 3. Kategori (Dropdown dinamis mengikuti Mode Animasi)
      Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(
          text = stringResource(R.string.label_category),
          style = MaterialTheme.typography.titleSmall,
          color = MaterialTheme.colorScheme.onSurface,
        )
        ExposedDropdownMenuBox(
          expanded = categoryDropdownExpanded,
          onExpandedChange = { categoryDropdownExpanded = it },
        ) {
          OutlinedTextField(
            value = state.selectedCategory,
            onValueChange = {},
            readOnly = true,
            modifier = Modifier
              .menuAnchor(MenuAnchorType.PrimaryNotEditable)
              .fillMaxWidth()
              .testTag("category_dropdown"),
            trailingIcon = {
              ExposedDropdownMenuDefaults.TrailingIcon(expanded = categoryDropdownExpanded)
            },
            supportingText = {
              Text(
                text = "Kategori menyesuaikan mode \"${state.selectedMode.id}\" (${state.selectedMode.categories.size} pilihan)",
              )
            },
            shape = MaterialTheme.shapes.small,
          )
          ExposedDropdownMenu(
            expanded = categoryDropdownExpanded,
            onDismissRequest = { categoryDropdownExpanded = false },
          ) {
            state.selectedMode.categories.forEach { category ->
              DropdownMenuItem(
                text = { Text(category) },
                onClick = {
                  onCategorySelected(category)
                  categoryDropdownExpanded = false
                },
                trailingIcon = if (category == state.selectedCategory) {
                  {
                    Icon(
                      imageVector = Icons.Filled.CheckCircle,
                      contentDescription = null,
                      tint = MaterialTheme.colorScheme.primary,
                      modifier = Modifier.size(18.dp),
                    )
                  }
                } else null,
              )
            }
          }
        }
      }

      // 4. Jenis File & Deskripsi Info Ikon (!)
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
          text = stringResource(R.string.label_file_format),
          style = MaterialTheme.typography.titleSmall,
          color = MaterialTheme.colorScheme.onSurface,
        )
        ExposedDropdownMenuBox(
          expanded = formatDropdownExpanded,
          onExpandedChange = { formatDropdownExpanded = it },
        ) {
          OutlinedTextField(
            value = state.selectedFormat,
            onValueChange = {},
            readOnly = true,
            modifier = Modifier
              .menuAnchor(MenuAnchorType.PrimaryNotEditable)
              .fillMaxWidth()
              .testTag("format_dropdown"),
            trailingIcon = {
              ExposedDropdownMenuDefaults.TrailingIcon(expanded = formatDropdownExpanded)
            },
            shape = MaterialTheme.shapes.small,
          )
          ExposedDropdownMenu(
            expanded = formatDropdownExpanded,
            onDismissRequest = { formatDropdownExpanded = false },
          ) {
            SkinOptions.fileFormats.forEach { format ->
              DropdownMenuItem(
                text = { Text(format) },
                onClick = {
                  onFormatSelected(format)
                  formatDropdownExpanded = false
                },
              )
            }
          }
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Text(
            text = stringResource(R.string.label_shape_desc),
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f),
          )
          IconButton(
            onClick = { showShapeInfoPreview = !showShapeInfoPreview },
            modifier = Modifier.testTag("shape_info_preview_button"),
          ) {
            Icon(
              imageVector = Icons.Filled.Info,
              contentDescription = "Pratinjau tooltip ikon info",
              tint = MaterialTheme.colorScheme.secondary,
            )
          }
        }

        AnimatedVisibility(visible = showShapeInfoPreview) {
          Surface(
            shape = MaterialTheme.shapes.small,
            color = MaterialTheme.colorScheme.secondaryContainer,
            modifier = Modifier.fillMaxWidth(),
          ) {
            Row(
              modifier = Modifier.padding(12.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              Icon(
                imageVector = Icons.Filled.Info,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSecondaryContainer,
                modifier = Modifier.size(18.dp),
              )
              Text(
                text = "Pratinjau Ikon (!): ${state.shapeInput.ifBlank { "(Belum diisi)" }}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSecondaryContainer,
              )
            }
          }
        }

        OutlinedTextField(
          value = state.shapeInput,
          onValueChange = onShapeInputChanged,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("shape_input"),
          placeholder = { Text(stringResource(R.string.hint_shape_desc)) },
          singleLine = true,
          shape = MaterialTheme.shapes.small,
        )

        Row(
          modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          SkinOptions.shapePresets.forEach { preset ->
            FilterChip(
              selected = state.shapeInput == preset,
              onClick = { onShapeInputChanged(preset) },
              label = { Text(preset, style = MaterialTheme.typography.labelMedium) },
              colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
              ),
            )
          }
        }
      }

      // 5. Pilih Gambar dari Galeri
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
          text = stringResource(R.string.label_pick_image),
          style = MaterialTheme.typography.titleSmall,
          color = MaterialTheme.colorScheme.onSurface,
        )

        if (state.selectedImageUri == null) {
          Surface(
            modifier = Modifier
              .fillMaxWidth()
              .height(148.dp)
              .clip(MaterialTheme.shapes.medium)
              .clickable(enabled = !state.isUploading) {
                photoPickerLauncher.launch(
                  PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly),
                )
              }
              .testTag("pick_image_box"),
            shape = MaterialTheme.shapes.medium,
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
            border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.outline),
          ) {
            Column(
              modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.Center,
            ) {
              Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.size(48.dp),
              ) {
                Icon(
                  imageVector = Icons.Filled.AddPhotoAlternate,
                  contentDescription = stringResource(R.string.btn_pick_image),
                  tint = MaterialTheme.colorScheme.primary,
                  modifier = Modifier.padding(12.dp),
                )
              }
              Spacer(modifier = Modifier.height(10.dp))
              Text(
                text = "Ketuk untuk memilih gambar dari galeri",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface,
              )
              Text(
                text = "Mendukung PNG transparan & JPG resolusi tinggi",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }
        } else {
          Surface(
            shape = MaterialTheme.shapes.medium,
            color = MaterialTheme.colorScheme.surfaceVariant,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.6f)),
            modifier = Modifier.fillMaxWidth(),
          ) {
            Column(modifier = Modifier.fillMaxWidth()) {
              Box(
                modifier = Modifier
                  .fillMaxWidth()
                  .height(210.dp)
                  .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)),
              ) {
                CheckerboardBackground(modifier = Modifier.fillMaxSize())
                AsyncImage(
                  model = state.selectedImageUri,
                  contentDescription = "Preview gambar skin terpilih",
                  contentScale = ContentScale.Fit,
                  modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp),
                )
                Surface(
                  color = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f),
                  shape = RoundedCornerShape(8.dp),
                  modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(10.dp),
                ) {
                  Text(
                    text = state.effectiveExtension.uppercase(),
                    style = MaterialTheme.typography.labelSmall.copy(
                      fontFamily = JetBrainsMonoFamily,
                      fontWeight = FontWeight.Bold,
                    ),
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                  )
                }
              }

              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .background(MaterialTheme.colorScheme.surfaceContainerLow)
                  .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    text = state.selectedImageDisplayName.ifBlank { "gambar_skin.${state.effectiveExtension}" },
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                  )
                  if (state.selectedImageSizeBytes > 0L) {
                    Text(
                      text = Formatter.formatShortFileSize(context, state.selectedImageSizeBytes),
                      style = MaterialTheme.typography.bodySmall,
                      color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                  }
                }
                TextButton(
                  onClick = {
                    photoPickerLauncher.launch(
                      PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly),
                    )
                  },
                  enabled = !state.isUploading,
                  modifier = Modifier.minimumInteractiveComponentSize(),
                ) {
                  Text(stringResource(R.string.btn_change_image))
                }
                IconButton(
                  onClick = onClearImage,
                  enabled = !state.isUploading,
                ) {
                  Icon(
                    imageVector = Icons.Filled.Close,
                    contentDescription = "Batalkan gambar terpilih",
                  )
                }
              }
            }
          }
        }
      }

      // Upload Progress Indicator
      AnimatedVisibility(visible = state.isUploading || state.isDeleting) {
        Surface(
          shape = MaterialTheme.shapes.small,
          color = MaterialTheme.colorScheme.secondaryContainer,
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            Text(
              text = state.progressMessage.ifBlank { "Memproses ke GitHub..." },
              style = MaterialTheme.typography.bodyMedium,
              fontWeight = FontWeight.SemiBold,
              color = MaterialTheme.colorScheme.onSecondaryContainer,
            )
            LinearProgressIndicator(
              modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(CircleShape),
            )
          }
        }
      }

      // Primary Save Button
      Button(
        onClick = onUploadClick,
        enabled = !state.isUploading && !state.isDeleting,
        modifier = Modifier
          .fillMaxWidth()
          .height(54.dp)
          .testTag("save_to_github_button"),
        shape = MaterialTheme.shapes.medium,
      ) {
        Icon(
          imageVector = Icons.Filled.CloudUpload,
          contentDescription = null,
          modifier = Modifier.size(20.dp),
        )
        Spacer(modifier = Modifier.width(10.dp))
        Text(
          text = if (state.isUploading) "Mengunggah ke GitHub..." else stringResource(R.string.btn_upload_github),
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
        )
      }
    }
  }
}

@Composable
private fun ModeSelectionButton(
  mode: AnimationMode,
  selected: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val borderColor = if (selected) {
    if (mode == AnimationMode.ANIM2) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary
  } else {
    MaterialTheme.colorScheme.outlineVariant
  }

  val containerColor = if (selected) {
    if (mode == AnimationMode.ANIM2) {
      MaterialTheme.colorScheme.secondaryContainer
    } else {
      MaterialTheme.colorScheme.primaryContainer
    }
  } else {
    MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
  }

  val contentColor = if (selected) {
    if (mode == AnimationMode.ANIM2) {
      MaterialTheme.colorScheme.onSecondaryContainer
    } else {
      MaterialTheme.colorScheme.onPrimaryContainer
    }
  } else {
    MaterialTheme.colorScheme.onSurface
  }

  Surface(
    modifier = modifier
      .clip(MaterialTheme.shapes.medium)
      .clickable(onClick = onClick)
      .minimumInteractiveComponentSize(),
    shape = MaterialTheme.shapes.medium,
    color = containerColor,
    border = BorderStroke(if (selected) 1.8.dp else 1.dp, borderColor),
  ) {
    Column(
      modifier = Modifier.padding(horizontal = 12.dp, vertical = 12.dp),
      verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Icon(
          imageVector = if (mode == AnimationMode.ANIM2) Icons.Filled.ViewInAr else Icons.Filled.Layers,
          contentDescription = null,
          tint = contentColor,
          modifier = Modifier.size(20.dp),
        )
        if (selected) {
          Icon(
            imageVector = Icons.Filled.CheckCircle,
            contentDescription = "Dipilih",
            tint = borderColor,
            modifier = Modifier.size(18.dp),
          )
        }
      }
      Text(
        text = mode.shortLabel,
        style = MaterialTheme.typography.titleSmall.copy(
          fontFamily = JetBrainsMonoFamily,
          fontWeight = FontWeight.Bold,
        ),
        color = contentColor,
      )
      Text(
        text = mode.displayLabel,
        style = MaterialTheme.typography.bodySmall,
        color = contentColor.copy(alpha = 0.85f),
        maxLines = 2,
        overflow = TextOverflow.Ellipsis,
      )
    }
  }
}
