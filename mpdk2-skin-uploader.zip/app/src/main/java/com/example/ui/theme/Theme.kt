package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
  primary = BronzeAmber,
  onPrimary = Color(0xFF1F1400),
  primaryContainer = BronzeAmberContainer,
  onPrimaryContainer = OnBronzeAmberContainer,
  secondary = CyanStudio,
  onSecondary = Color(0xFF002438),
  secondaryContainer = CyanStudioContainer,
  onSecondaryContainer = OnCyanStudioContainer,
  tertiary = EmeraldSuccess,
  onTertiary = Color(0xFF002418),
  tertiaryContainer = EmeraldContainer,
  onTertiaryContainer = OnEmeraldContainer,
  error = CoralError,
  onError = Color(0xFF3F0407),
  errorContainer = CoralErrorContainer,
  onErrorContainer = OnCoralErrorContainer,
  background = StudioObsidian,
  onBackground = Color(0xFFF3F4F6),
  surface = StudioSurface,
  onSurface = Color(0xFFF3F4F6),
  surfaceVariant = StudioSurfaceHigh,
  onSurfaceVariant = Color(0xFF9CA3AF),
  surfaceContainerLowest = StudioObsidian,
  surfaceContainerLow = StudioSurface,
  surfaceContainer = StudioSurfaceHigh,
  surfaceContainerHigh = StudioSurfaceHighest,
  outline = StudioOutline,
  outlineVariant = StudioOutlineSubtle,
)

private val LightColorScheme = lightColorScheme(
  primary = BronzeAmberDark,
  onPrimary = Color.White,
  primaryContainer = LightBronzeContainer,
  onPrimaryContainer = LightOnBronzeContainer,
  secondary = CyanStudioDark,
  onSecondary = Color.White,
  secondaryContainer = LightCyanContainer,
  onSecondaryContainer = LightOnCyanContainer,
  tertiary = EmeraldSuccess,
  onTertiary = Color.White,
  error = CoralErrorDark,
  onError = Color.White,
  background = LightBackground,
  onBackground = LightOnSurface,
  surface = LightSurface,
  onSurface = LightOnSurface,
  surfaceVariant = LightSurfaceVariant,
  onSurfaceVariant = LightOnSurfaceVariant,
  surfaceContainerLowest = Color.White,
  surfaceContainerLow = Color(0xFFFAF9F6),
  surfaceContainer = LightSurfaceVariant,
  surfaceContainerHigh = Color(0xFFE3E0D6),
  outline = LightOutline,
  outlineVariant = Color(0xFFE5E2D9),
)

val AppShapes = Shapes(
  small = RoundedCornerShape(10.dp),
  medium = RoundedCornerShape(16.dp),
  large = RoundedCornerShape(22.dp),
  extraLarge = RoundedCornerShape(28.dp),
)

@Composable
fun Mpdk2UploaderTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
  val view = LocalView.current
  if (!view.isInEditMode) {
    SideEffect {
      val window = (view.context as? Activity)?.window
      if (window != null) {
        WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
      }
    }
  }

  MaterialTheme(
    colorScheme = colorScheme,
    typography = AppTypography,
    shapes = AppShapes,
    content = content,
  )
}
