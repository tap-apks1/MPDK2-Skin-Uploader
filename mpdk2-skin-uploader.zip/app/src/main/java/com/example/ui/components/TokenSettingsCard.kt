package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.JetBrainsMonoFamily

@Composable
fun TokenSettingsCard(
  tokenInput: String,
  hasToken: Boolean,
  githubUsername: String,
  isExpanded: Boolean,
  isVerifying: Boolean,
  onToggleExpand: () -> Unit,
  onTokenInputChanged: (String) -> Unit,
  onSaveToken: () -> Unit,
  onClearToken: () -> Unit,
  modifier: Modifier = Modifier,
) {
  var showToken by rememberSaveable { mutableStateOf(false) }

  Card(
    modifier = modifier.fillMaxWidth(),
    shape = MaterialTheme.shapes.large,
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(
      width = 1.dp,
      color = if (hasToken) {
        MaterialTheme.colorScheme.outlineVariant
      } else {
        MaterialTheme.colorScheme.primary.copy(alpha = 0.6f)
      },
    ),
  ) {
    Column(modifier = Modifier.fillMaxWidth()) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(MaterialTheme.shapes.large)
          .clickable(onClick = onToggleExpand)
          .minimumInteractiveComponentSize()
          .padding(horizontal = 16.dp, vertical = 14.dp)
          .testTag("token_card_header"),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = if (hasToken) {
            MaterialTheme.colorScheme.tertiaryContainer
          } else {
            MaterialTheme.colorScheme.primaryContainer
          },
          modifier = Modifier.size(40.dp),
        ) {
          Icon(
            imageVector = if (hasToken) Icons.Filled.CheckCircle else Icons.Filled.Key,
            contentDescription = stringResource(R.string.section_github_token),
            tint = if (hasToken) {
              MaterialTheme.colorScheme.tertiary
            } else {
              MaterialTheme.colorScheme.primary
            },
            modifier = Modifier.padding(9.dp),
          )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = stringResource(R.string.section_github_token),
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface,
          )
          Spacer(modifier = Modifier.height(2.dp))
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
          ) {
            Text(
              text = if (hasToken) {
                if (githubUsername.isNotBlank()) "Terhubung • @$githubUsername" else "Token Tersimpan"
              } else {
                "Wajib diisi untuk commit ke GitHub"
              },
              style = MaterialTheme.typography.bodySmall,
              color = if (hasToken) {
                MaterialTheme.colorScheme.tertiary
              } else {
                MaterialTheme.colorScheme.primary
              },
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
          }
        }

        Icon(
          imageVector = if (isExpanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
          contentDescription = if (isExpanded) "Tutup pengaturan token" else "Buka pengaturan token",
          tint = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }

      AnimatedVisibility(
        visible = isExpanded,
        enter = expandVertically() + fadeIn(),
        exit = shrinkVertically() + fadeOut(),
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 16.dp, bottom = 16.dp),
          verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.fillMaxWidth(),
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Icon(
                imageVector = Icons.Outlined.Lock,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.size(16.dp),
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "Target: tap-apks1/mpdk2-skins (branch: main)",
                style = MaterialTheme.typography.bodySmall.copy(fontFamily = JetBrainsMonoFamily),
                color = MaterialTheme.colorScheme.onSurface,
              )
            }
          }

          OutlinedTextField(
            value = tokenInput,
            onValueChange = onTokenInputChanged,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("github_pat_input"),
            label = { Text("GitHub Personal Access Token (PAT)") },
            placeholder = {
              Text(
                text = stringResource(R.string.token_hint),
                fontFamily = JetBrainsMonoFamily,
              )
            },
            singleLine = true,
            visualTransformation = if (showToken) VisualTransformation.None else PasswordVisualTransformation(),
            trailingIcon = {
              IconButton(
                onClick = { showToken = !showToken },
                modifier = Modifier.testTag("toggle_token_visibility"),
              ) {
                Icon(
                  imageVector = if (showToken) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                  contentDescription = if (showToken) "Sembunyikan token" else "Tampilkan token",
                )
              }
            },
            supportingText = {
              Text(text = stringResource(R.string.token_helper))
            },
            shape = MaterialTheme.shapes.small,
          )

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            Button(
              onClick = onSaveToken,
              enabled = !isVerifying && tokenInput.isNotBlank(),
              modifier = Modifier
                .weight(1f)
                .height(48.dp)
                .testTag("save_token_button"),
              shape = MaterialTheme.shapes.small,
            ) {
              if (isVerifying) {
                CircularProgressIndicator(
                  modifier = Modifier.size(18.dp),
                  strokeWidth = 2.dp,
                  color = MaterialTheme.colorScheme.onPrimary,
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Memverifikasi...")
              } else {
                Text(
                  text = stringResource(R.string.btn_save_token),
                  fontWeight = FontWeight.SemiBold,
                )
              }
            }

            if (hasToken) {
              OutlinedButton(
                onClick = onClearToken,
                enabled = !isVerifying,
                modifier = Modifier
                  .height(48.dp)
                  .testTag("clear_token_button"),
                shape = MaterialTheme.shapes.small,
                colors = ButtonDefaults.outlinedButtonColors(
                  contentColor = MaterialTheme.colorScheme.error,
                ),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.5f)),
              ) {
                Icon(
                  imageVector = Icons.Outlined.DeleteOutline,
                  contentDescription = stringResource(R.string.btn_clear_token),
                  modifier = Modifier.size(18.dp),
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Hapus")
              }
            }
          }
        }
      }
    }
  }
}
