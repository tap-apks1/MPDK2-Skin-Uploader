package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Studio Obsidian & Bronze Cymbal Palette
val StudioObsidian = Color(0xFF111318)
val StudioSurface = Color(0xFF181B22)
val StudioSurfaceHigh = Color(0xFF212630)
val StudioSurfaceHighest = Color(0xFF2B313E)
val StudioOutline = Color(0xFF394050)
val StudioOutlineSubtle = Color(0xFF282E3A)

val BronzeAmber = Color(0xFFF59E0B)
val BronzeAmberLight = Color(0xFFFBBF24)
val BronzeAmberDark = Color(0xFFD97706)
val BronzeAmberContainer = Color(0xFF3A280A)
val OnBronzeAmberContainer = Color(0xFFFDE68A)

val CyanStudio = Color(0xFF38BDF8)
val CyanStudioDark = Color(0xFF0284C7)
val CyanStudioContainer = Color(0xFF0C2D42)
val OnCyanStudioContainer = Color(0xFFBAE6FD)

val EmeraldSuccess = Color(0xFF10B981)
val EmeraldContainer = Color(0xFF0B3528)
val OnEmeraldContainer = Color(0xFFA7F3D0)

val CoralError = Color(0xFFF87171)
val CoralErrorDark = Color(0xFFDC2626)
val CoralErrorContainer = Color(0xFF3E1418)
val OnCoralErrorContainer = Color(0xFFFECACA)

// Light palette tokens
val LightBackground = Color(0xFFF6F5F1)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFECEAE3)
val LightOutline = Color(0xFFD0CCC0)
val LightOnSurface = Color(0xFF16181E)
val LightOnSurfaceVariant = Color(0xFF575B66)
val LightBronzeContainer = Color(0xFFFEF3C7)
val LightOnBronzeContainer = Color(0xFF78350F)
val LightCyanContainer = Color(0xFFE0F2FE)
val LightOnCyanContainer = Color(0xFF075985)
