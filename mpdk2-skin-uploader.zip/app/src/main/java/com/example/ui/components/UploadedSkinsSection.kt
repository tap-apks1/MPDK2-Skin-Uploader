package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.BrokenImage
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.SubcomposeAsyncImage
import coil.request.ImageRequest
import com.example.R
import com.example.data.remote.GitHubRepoConfig
import com.example.model.SkinItem
import com.example.ui.ModeFilter
import com.example.ui.SkinsUiState
import com.example.ui.theme.JetBrainsMonoFamily

@Composable
fun UploadedSkinsHeaderCard(
  state: SkinsUiState,
  onModeFilterSelected: (ModeFilter) -> Unit,
  onSearchQueryChanged: (String) -> Unit,
  onRefreshClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Column(
    modifier = modifier.fillMaxWidth(),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Text(
          text = stringResource(R.string.section_uploaded_list),
          style = MaterialTheme.typography.titleLarge,
          color = MaterialTheme.colorScheme.onBackground,
        )
        Surface(
          shape = RoundedCornerShape(999.dp),
          color = MaterialTheme.colorScheme.primaryContainer,
        ) {
          Text(
            text = "${state.skins.size}",
            style = MaterialTheme.typography.labelMedium.copy(
              fontFamily = JetBrainsMonoFamily,
              fontWeight = FontWeight.Bold,
            ),
            color = MaterialTheme.colorScheme.onPrimaryContainer,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp),
          )
        }
      }

      OutlinedButton(
        onClick = onRefreshClick,
        enabled = !state.isLoadingSkins && state.hasToken,
        modifier = Modifier.testTag("refresh_skins_button"),
        shape = MaterialTheme.shapes.small,
      ) {
        if (state.isLoadingSkins) {
          CircularProgressIndicator(
            modifier = Modifier.size(16.dp),
            strokeWidth = 2.dp,
          )
        } else {
          Icon(
            imageVector = Icons.Filled.Refresh,
            contentDescription = stringResource(R.string.btn_refresh_list),
            modifier = Modifier.size(18.dp),
          )
        }
        Spacer(modifier = Modifier.width(6.dp))
        Text(stringResource(R.string.btn_refresh_list))
      }
    }

    OutlinedTextField(
      value = state.searchQuery,
      onValueChange = onSearchQueryChanged,
      modifier = Modifier
        .fillMaxWidth()
        .testTag("search_skins_input"),
      placeholder = { Text("Cari nama skin, kategori, atau shape...") },
      leadingIcon = {
        Icon(
          imageVector = Icons.Filled.Search,
          contentDescription = null,
        )
      },
      trailingIcon = {
        if (state.searchQuery.isNotEmpty()) {
          IconButton(onClick = { onSearchQueryChanged("") }) {
            Icon(
              imageVector = Icons.Filled.Close,
              contentDescription = "Hapus pencarian",
            )
          }
        }
      },
      singleLine = true,
      shape = MaterialTheme.shapes.small,
    )

    Row(
      modifier = Modifier
        .fillMaxWidth()
        .horizontalScroll(rememberScrollState()),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      ModeFilter.entries.forEach { filter ->
        val count = when (filter) {
          ModeFilter.ALL -> state.skins.size
          ModeFilter.DEFAULT -> state.skins.count { it.mode.equals("default", ignoreCase = true) }
          ModeFilter.ANIM2 -> state.skins.count { it.mode.equals("anim2", ignoreCase = true) }
        }
        FilterChip(
          selected = state.modeFilter == filter,
          onClick = { onModeFilterSelected(filter) },
          label = {
            Text(
              text = "${filter.label} ($count)",
              fontFamily = if (filter == ModeFilter.ALL) MaterialTheme.typography.labelMedium.fontFamily else JetBrainsMonoFamily,
            )
          },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = MaterialTheme.colorScheme.secondaryContainer,
            selectedLabelColor = MaterialTheme.colorScheme.onSecondaryContainer,
          ),
        )
      }
    }
  }
}

@Composable
fun SkinItemCard(
  item: SkinItem,
  savedToken: String,
  isBusy: Boolean,
  onDeleteClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  var showShapeDetails by remember(item.image) { mutableStateOf(false) }

  val isAnim2 = item.mode.equals("anim2", ignoreCase = true)
  val rawImageUrl = remember(item.image) { GitHubRepoConfig.rawUrl(item.image) }

  val imageRequest = remember(rawImageUrl, savedToken) {
    ImageRequest.Builder(context)
      .data(rawImageUrl)
      .apply {
        if (savedToken.isNotBlank()) {
          addHeader("Authorization", "Bearer $savedToken")
        }
      }
      .crossfade(true)
      .build()
  }

  Card(
    modifier = modifier.fillMaxWidth(),
    shape = MaterialTheme.shapes.medium,
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
  ) {
    Column(modifier = Modifier.fillMaxWidth()) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Box(
          modifier = Modifier
            .size(76.dp)
            .clip(RoundedCornerShape(12.dp)),
        ) {
          CheckerboardBackground(modifier = Modifier.fillMaxSize())
          SubcomposeAsyncImage(
            model = imageRequest,
            contentDescription = "Gambar ${item.name}",
            contentScale = ContentScale.Fit,
            modifier = Modifier
              .fillMaxSize()
              .padding(6.dp),
            loading = {
              Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
              }
            },
            error = {
              Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Icon(
                  imageVector = Icons.Outlined.BrokenImage,
                  contentDescription = "Gagal memuat gambar",
                  tint = MaterialTheme.colorScheme.onSurfaceVariant,
                  modifier = Modifier.size(24.dp),
                )
              }
            },
          )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(
          modifier = Modifier.weight(1f),
          verticalArrangement = Arrangement.spacedBy(5.dp),
        ) {
          Text(
            text = item.name,
            style = MaterialTheme.typography.titleSmall.copy(
              fontFamily = JetBrainsMonoFamily,
              fontWeight = FontWeight.Bold,
            ),
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )

          Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Surface(
              shape = RoundedCornerShape(6.dp),
              color = if (isAnim2) {
                MaterialTheme.colorScheme.secondaryContainer
              } else {
                MaterialTheme.colorScheme.primaryContainer
              },
            ) {
              Text(
                text = item.mode,
                style = MaterialTheme.typography.labelSmall.copy(
                  fontFamily = JetBrainsMonoFamily,
                  fontWeight = FontWeight.Bold,
                ),
                color = if (isAnim2) {
                  MaterialTheme.colorScheme.onSecondaryContainer
                } else {
                  MaterialTheme.colorScheme.onPrimaryContainer
                },
                modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp),
              )
            }

            Surface(
              shape = RoundedCornerShape(6.dp),
              color = MaterialTheme.colorScheme.surfaceVariant,
            ) {
              Text(
                text = item.category,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp),
              )
            }
          }

          Text(
            text = item.format,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }

        IconButton(
          onClick = { showShapeDetails = !showShapeDetails },
          modifier = Modifier.testTag("info_shape_button_${item.name}"),
        ) {
          Icon(
            imageVector = Icons.Filled.Info,
            contentDescription = "Lihat deskripsi bentuk aset",
            tint = if (showShapeDetails) {
              MaterialTheme.colorScheme.secondary
            } else {
              MaterialTheme.colorScheme.onSurfaceVariant
            },
          )
        }

        IconButton(
          onClick = onDeleteClick,
          enabled = !isBusy,
          modifier = Modifier.testTag("delete_skin_button_${item.name}"),
        ) {
          Icon(
            imageVector = Icons.Outlined.DeleteOutline,
            contentDescription = "Hapus ${item.name}",
            tint = MaterialTheme.colorScheme.error,
          )
        }
      }

      AnimatedVisibility(visible = showShapeDetails) {
        Surface(
          color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp),
          ) {
            Text(
              text = "Info (!): ${item.shape.ifBlank { "-" }}",
              style = MaterialTheme.typography.bodySmall,
              fontWeight = FontWeight.SemiBold,
              color = MaterialTheme.colorScheme.onSurface,
            )
            Text(
              text = item.image,
              style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
          }
        }
      }
    }
  }
}

@Composable
fun EmptySkinsStateCard(
  hasToken: Boolean,
  isFilteredEmpty: Boolean,
  modifier: Modifier = Modifier,
) {
  Card(
    modifier = modifier.fillMaxWidth(),
    shape = MaterialTheme.shapes.large,
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Image(
        painter = painterResource(id = R.drawable.img_drum_studio_empty),
        contentDescription = "Ilustrasi studio drum MPDK2",
        contentScale = ContentScale.Crop,
        modifier = Modifier
          .fillMaxWidth()
          .height(140.dp)
          .clip(MaterialTheme.shapes.medium),
      )

      Text(
        text = if (isFilteredEmpty) {
          "Tidak ada skin yang cocok"
        } else {
          stringResource(R.string.empty_skins_title)
        },
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.onSurface,
      )

      Text(
        text = when {
          isFilteredEmpty -> "Coba ubah kata kunci pencarian atau pilih filter mode \"Semua\"."
          !hasToken -> "Simpan Token GitHub (PAT) di atas untuk memuat daftar skin dari tap-apks1/mpdk2-skins."
          else -> stringResource(R.string.empty_skins_subtitle)
        },
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
    }
  }
}

@Composable
fun DeleteSkinConfirmationDialog(
  item: SkinItem,
  onConfirm: () -> Unit,
  onDismiss: () -> Unit,
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Text(
        text = stringResource(R.string.dialog_delete_title),
        style = MaterialTheme.typography.titleLarge,
      )
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
          text = "Entri berikut akan dihapus dari skins.json sekaligus file gambarnya dari repositori GitHub:",
          style = MaterialTheme.typography.bodyMedium,
        )
        Surface(
          shape = MaterialTheme.shapes.small,
          color = MaterialTheme.colorScheme.surfaceVariant,
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(
              text = item.name,
              style = MaterialTheme.typography.titleSmall.copy(fontFamily = JetBrainsMonoFamily),
            )
            Text(
              text = "${item.mode} • ${item.category}",
              style = MaterialTheme.typography.bodySmall,
            )
            Text(
              text = item.image,
              style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        }
      }
    },
    confirmButton = {
      TextButton(
        onClick = onConfirm,
        colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error),
        modifier = Modifier.testTag("confirm_delete_button"),
      ) {
        Text(
          text = stringResource(R.string.dialog_delete_confirm),
          fontWeight = FontWeight.Bold,
        )
      }
    },
    dismissButton = {
      TextButton(
        onClick = onDismiss,
        modifier = Modifier.testTag("cancel_delete_button"),
      ) {
        Text(stringResource(R.string.dialog_cancel))
      }
    },
  )
}
