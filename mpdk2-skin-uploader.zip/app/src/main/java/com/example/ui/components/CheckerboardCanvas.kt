package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Composable
fun CheckerboardBackground(
  modifier: Modifier = Modifier,
  squareSize: Dp = 10.dp,
) {
  val isDark = isSystemInDarkTheme()
  val lightSquare = if (isDark) Color(0xFF262B36) else Color(0xFFF0EFE9)
  val darkSquare = if (isDark) Color(0xFF1B1F28) else Color(0xFFE0DDD2)

  Canvas(modifier = modifier) {
    val cellPx = squareSize.toPx().coerceAtLeast(4f)
    val cols = (size.width / cellPx).toInt() + 1
    val rows = (size.height / cellPx).toInt() + 1

    for (row in 0 until rows) {
      for (col in 0 until cols) {
        val color = if ((row + col) % 2 == 0) lightSquare else darkSquare
        drawRect(
          color = color,
          topLeft = Offset(col * cellPx, row * cellPx),
          size = Size(cellPx, cellPx),
        )
      }
    }
  }
}
