package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.ui.components.DeleteSkinConfirmationDialog
import com.example.ui.components.EmptySkinsStateCard
import com.example.ui.components.SkinItemCard
import com.example.ui.components.TokenSettingsCard
import com.example.ui.components.UploadSkinFormCard
import com.example.ui.components.UploadedSkinsHeaderCard
import com.example.ui.theme.JetBrainsMonoFamily

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
  viewModel: SkinsViewModel,
  modifier: Modifier = Modifier,
) {
  val state by viewModel.uiState.collectAsStateWithLifecycle()

  state.pendingDeleteItem?.let { item ->
    DeleteSkinConfirmationDialog(
      item = item,
      onConfirm = viewModel::confirmDelete,
      onDismiss = viewModel::dismissDeleteDialog,
    )
  }

  Scaffold(
    modifier = modifier.fillMaxSize(),
    contentWindowInsets = WindowInsets(0, 0, 0, 0),
    topBar = {
      TopAppBar(
        title = {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = MaterialTheme.colorScheme.primaryContainer,
              modifier = Modifier.size(36.dp),
            ) {
              Icon(
                imageVector = Icons.Filled.GraphicEq,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(7.dp),
              )
            }
            Column {
              Text(
                text = stringResource(R.string.app_title),
                style = MaterialTheme.typography.titleMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
              Text(
                text = stringResource(R.string.repo_target_label),
                style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            }
          }
        },
        actions = {
          IconButton(
            onClick = viewModel::toggleTokenSection,
            modifier = Modifier.testTag("topbar_token_toggle"),
          ) {
            Icon(
              imageVector = Icons.Filled.Key,
              contentDescription = "Pengaturan Token GitHub",
              tint = if (state.hasToken) {
                MaterialTheme.colorScheme.tertiary
              } else {
                MaterialTheme.colorScheme.primary
              },
            )
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = MaterialTheme.colorScheme.surface,
          scrolledContainerColor = MaterialTheme.colorScheme.surface,
        ),
      )
    },
  ) { innerPadding ->
    val backdropBrush = Brush.verticalGradient(
      colors = listOf(
        MaterialTheme.colorScheme.background,
        MaterialTheme.colorScheme.surfaceContainerLowest,
      ),
    )

    BoxWithConstraints(
      modifier = Modifier
        .fillMaxSize()
        .background(backdropBrush)
        .padding(innerPadding),
    ) {
      val isWideLayout = maxWidth >= 840.dp

      if (isWideLayout) {
        Row(
          modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp, vertical = 16.dp)
            .navigationBarsPadding(),
          horizontalArrangement = Arrangement.spacedBy(24.dp),
        ) {
          Column(
            modifier = Modifier
              .weight(1f)
              .fillMaxHeight()
              .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp),
          ) {
            StatusBannerSection(
              banner = state.statusBanner,
              onDismiss = viewModel::dismissBanner,
            )
            TokenSettingsCard(
              tokenInput = state.tokenInput,
              hasToken = state.hasToken,
              githubUsername = state.githubUsername,
              isExpanded = state.isTokenSectionExpanded,
              isVerifying = state.isVerifyingToken,
              onToggleExpand = viewModel::toggleTokenSection,
              onTokenInputChanged = viewModel::onTokenInputChanged,
              onSaveToken = viewModel::saveAndVerifyToken,
              onClearToken = viewModel::clearSavedToken,
            )
            UploadSkinFormCard(
              state = state,
              onSkinNameChanged = viewModel::onSkinNameChanged,
              onModeSelected = viewModel::onModeSelected,
              onCategorySelected = viewModel::onCategorySelected,
              onFormatSelected = viewModel::onFormatSelected,
              onShapeInputChanged = viewModel::onShapeInputChanged,
              onImageSelected = viewModel::onImageSelected,
              onClearImage = viewModel::clearSelectedImage,
              onUploadClick = viewModel::uploadSkin,
            )
          }

          LazyColumn(
            modifier = Modifier
              .weight(1f)
              .fillMaxHeight(),
            contentPadding = PaddingValues(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
          ) {
            item(key = "header") {
              UploadedSkinsHeaderCard(
                state = state,
                onModeFilterSelected = viewModel::onModeFilterSelected,
                onSearchQueryChanged = viewModel::onSearchQueryChanged,
                onRefreshClick = { viewModel.refreshSkins(silentIfEmpty = false) },
              )
            }
            if (state.filteredSkins.isEmpty()) {
              item(key = "empty") {
                EmptySkinsStateCard(
                  hasToken = state.hasToken,
                  isFilteredEmpty = state.skins.isNotEmpty(),
                )
              }
            } else {
              items(
                items = state.filteredSkins,
                key = { "${it.mode}_${it.name}_${it.image}" },
              ) { item ->
                SkinItemCard(
                  item = item,
                  savedToken = state.savedToken,
                  isBusy = state.isUploading || state.isDeleting,
                  onDeleteClick = { viewModel.requestDelete(item) },
                )
              }
            }
          }
        }
      } else {
        Box(
          modifier = Modifier.fillMaxSize(),
          contentAlignment = Alignment.TopCenter,
        ) {
          LazyColumn(
            modifier = Modifier
              .fillMaxHeight()
              .fillMaxWidth()
              .widthIn(max = 620.dp),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
          ) {
            item(key = "banner") {
              StatusBannerSection(
                banner = state.statusBanner,
                onDismiss = viewModel::dismissBanner,
              )
            }

            item(key = "token_settings") {
              TokenSettingsCard(
                tokenInput = state.tokenInput,
                hasToken = state.hasToken,
                githubUsername = state.githubUsername,
                isExpanded = state.isTokenSectionExpanded,
                isVerifying = state.isVerifyingToken,
                onToggleExpand = viewModel::toggleTokenSection,
                onTokenInputChanged = viewModel::onTokenInputChanged,
                onSaveToken = viewModel::saveAndVerifyToken,
                onClearToken = viewModel::clearSavedToken,
              )
            }

            item(key = "upload_form") {
              UploadSkinFormCard(
                state = state,
                onSkinNameChanged = viewModel::onSkinNameChanged,
                onModeSelected = viewModel::onModeSelected,
                onCategorySelected = viewModel::onCategorySelected,
                onFormatSelected = viewModel::onFormatSelected,
                onShapeInputChanged = viewModel::onShapeInputChanged,
                onImageSelected = viewModel::onImageSelected,
                onClearImage = viewModel::clearSelectedImage,
                onUploadClick = viewModel::uploadSkin,
              )
            }

            item(key = "skins_header") {
              Spacer(modifier = Modifier.height(4.dp))
              UploadedSkinsHeaderCard(
                state = state,
                onModeFilterSelected = viewModel::onModeFilterSelected,
                onSearchQueryChanged = viewModel::onSearchQueryChanged,
                onRefreshClick = { viewModel.refreshSkins(silentIfEmpty = false) },
              )
            }

            if (state.filteredSkins.isEmpty()) {
              item(key = "empty_state") {
                EmptySkinsStateCard(
                  hasToken = state.hasToken,
                  isFilteredEmpty = state.skins.isNotEmpty(),
                )
              }
            } else {
              items(
                items = state.filteredSkins,
                key = { "${it.mode}_${it.name}_${it.image}" },
              ) { item ->
                SkinItemCard(
                  item = item,
                  savedToken = state.savedToken,
                  isBusy = state.isUploading || state.isDeleting,
                  onDeleteClick = { viewModel.requestDelete(item) },
                )
              }
            }

            item(key = "bottom_nav_inset") {
              Spacer(modifier = Modifier.navigationBarsPadding())
            }
          }
        }
      }
    }
  }
}

@Composable
private fun StatusBannerSection(
  banner: StatusBanner?,
  onDismiss: () -> Unit,
) {
  AnimatedVisibility(
    visible = banner != null,
    enter = fadeIn(),
    exit = fadeOut(),
  ) {
    if (banner != null) {
      val containerColor = when (banner) {
        is StatusBanner.Success -> MaterialTheme.colorScheme.tertiaryContainer
        is StatusBanner.Error -> MaterialTheme.colorScheme.errorContainer
        is StatusBanner.Info -> MaterialTheme.colorScheme.secondaryContainer
      }
      val contentColor = when (banner) {
        is StatusBanner.Success -> MaterialTheme.colorScheme.onTertiaryContainer
        is StatusBanner.Error -> MaterialTheme.colorScheme.onErrorContainer
        is StatusBanner.Info -> MaterialTheme.colorScheme.onSecondaryContainer
      }
      val icon = when (banner) {
        is StatusBanner.Success -> Icons.Filled.CheckCircle
        is StatusBanner.Error -> Icons.Filled.Error
        is StatusBanner.Info -> Icons.Filled.Info
      }

      Surface(
        shape = MaterialTheme.shapes.medium,
        color = containerColor,
        border = BorderStroke(1.dp, contentColor.copy(alpha = 0.25f)),
        modifier = Modifier
          .fillMaxWidth()
          .testTag("status_banner"),
      ) {
        Row(
          modifier = Modifier.padding(start = 12.dp, top = 10.dp, bottom = 10.dp, end = 4.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Icon(
            imageVector = icon,
            contentDescription = null,
            tint = contentColor,
            modifier = Modifier.size(20.dp),
          )
          Spacer(modifier = Modifier.width(10.dp))
          Text(
            text = banner.message,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Medium,
            color = contentColor,
            modifier = Modifier.weight(1f),
          )
          IconButton(onClick = onDismiss) {
            Icon(
              imageVector = Icons.Filled.Close,
              contentDescription = "Tutup notifikasi",
              tint = contentColor,
              modifier = Modifier.size(18.dp),
            )
          }
        }
      }
    }
  }
}
