package com.example.ui

import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.TokenStore
import com.example.data.remote.GitHubApiService
import com.example.data.repository.GitHubSkinsRepository
import com.example.model.AnimationMode
import com.example.model.SkinItem
import com.example.model.SkinNameFormatter
import com.example.model.SkinOptions
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class ModeFilter(val label: String, val modeId: String?) {
  ALL("Semua", null),
  DEFAULT("default", "default"),
  ANIM2("anim2", "anim2"),
}

sealed interface StatusBanner {
  val message: String

  data class Success(override val message: String) : StatusBanner
  data class Error(override val message: String) : StatusBanner
  data class Info(override val message: String) : StatusBanner
}

data class SkinsUiState(
  val tokenInput: String = "",
  val savedToken: String = "",
  val githubUsername: String = "",
  val isTokenSectionExpanded: Boolean = true,
  val isVerifyingToken: Boolean = false,

  val skinNameInput: String = "",
  val selectedMode: AnimationMode = AnimationMode.ANIM2,
  val selectedCategory: String = AnimationMode.ANIM2.categories.first(),
  val selectedFormat: String = SkinOptions.fileFormats.first(),
  val shapeInput: String = SkinOptions.shapePresets.first(),
  val selectedImageUri: Uri? = null,
  val selectedImageExtension: String = "png",
  val selectedImageDisplayName: String = "",
  val selectedImageSizeBytes: Long = 0L,

  val isUploading: Boolean = false,
  val progressMessage: String = "",
  val isLoadingSkins: Boolean = false,
  val isDeleting: Boolean = false,

  val skins: List<SkinItem> = emptyList(),
  val modeFilter: ModeFilter = ModeFilter.ALL,
  val searchQuery: String = "",
  val pendingDeleteItem: SkinItem? = null,
  val statusBanner: StatusBanner? = null,
) {
  val hasToken: Boolean get() = savedToken.isNotBlank()
  val finalizedSkinName: String get() = SkinNameFormatter.finalizeName(skinNameInput)
  val effectiveExtension: String
    get() = if (selectedImageUri != null && selectedImageExtension.isNotBlank()) {
      selectedImageExtension
    } else {
      SkinOptions.defaultExtensionForFormat(selectedFormat)
    }

  val previewTargetPath: String
    get() {
      val namePart = finalizedSkinName.ifBlank { "nama_skin" }
      return "assets/${selectedMode.id}/${namePart}_<timestamp>.$effectiveExtension"
    }

  val filteredSkins: List<SkinItem>
    get() {
      val query = searchQuery.trim().lowercase()
      return skins.filter { item ->
        val matchesMode = modeFilter.modeId == null || item.mode.equals(modeFilter.modeId, ignoreCase = true)
        val matchesQuery = query.isEmpty() ||
          item.name.lowercase().contains(query) ||
          item.category.lowercase().contains(query) ||
          item.shape.lowercase().contains(query) ||
          item.format.lowercase().contains(query)
        matchesMode && matchesQuery
      }
    }
}

class SkinsViewModel(
  application: Application,
  private val tokenStore: TokenStore,
  private val repository: GitHubSkinsRepository,
) : AndroidViewModel(application) {

  private val _uiState = MutableStateFlow(SkinsUiState())
  val uiState: StateFlow<SkinsUiState> = _uiState.asStateFlow()

  init {
    viewModelScope.launch {
      val saved = tokenStore.authConfigFlow.first()
      if (saved.token.isNotBlank()) {
        _uiState.update {
          it.copy(
            tokenInput = saved.token,
            savedToken = saved.token,
            githubUsername = saved.username,
            isTokenSectionExpanded = false,
          )
        }
        refreshSkins(silentIfEmpty = false)
      }
    }
  }

  fun toggleTokenSection() {
    _uiState.update { it.copy(isTokenSectionExpanded = !it.isTokenSectionExpanded) }
  }

  fun onTokenInputChanged(value: String) {
    _uiState.update { it.copy(tokenInput = value) }
  }

  fun saveAndVerifyToken() {
    val candidate = _uiState.value.tokenInput.trim()
    if (candidate.isBlank()) {
      _uiState.update {
        it.copy(statusBanner = StatusBanner.Error("Masukkan GitHub Personal Access Token terlebih dahulu."))
      }
      return
    }

    viewModelScope.launch {
      _uiState.update { it.copy(isVerifyingToken = true, statusBanner = null) }
      val verifyResult = repository.verifyToken(candidate)
      verifyResult.fold(
        onSuccess = { username ->
          tokenStore.saveToken(candidate, username)
          _uiState.update {
            it.copy(
              isVerifyingToken = false,
              savedToken = candidate,
              tokenInput = candidate,
              githubUsername = username,
              isTokenSectionExpanded = false,
              statusBanner = StatusBanner.Success("Token tersimpan & terhubung sebagai @$username"),
            )
          }
          refreshSkins(silentIfEmpty = false)
        },
        onFailure = { error ->
          _uiState.update {
            it.copy(
              isVerifyingToken = false,
              statusBanner = StatusBanner.Error(error.message ?: "Gagal memverifikasi token GitHub."),
            )
          }
        },
      )
    }
  }

  fun clearSavedToken() {
    viewModelScope.launch {
      tokenStore.clearToken()
      _uiState.update {
        it.copy(
          tokenInput = "",
          savedToken = "",
          githubUsername = "",
          isTokenSectionExpanded = true,
          skins = emptyList(),
          statusBanner = StatusBanner.Info("Token GitHub dihapus dari penyimpanan lokal."),
        )
      }
    }
  }

  fun onSkinNameChanged(raw: String) {
    val formatted = SkinNameFormatter.formatWhileTyping(raw)
    _uiState.update { it.copy(skinNameInput = formatted) }
  }

  fun onModeSelected(mode: AnimationMode) {
    _uiState.update { state ->
      val validCategory = if (state.selectedCategory in mode.categories) {
        state.selectedCategory
      } else {
        mode.categories.first()
      }
      state.copy(
        selectedMode = mode,
        selectedCategory = validCategory,
      )
    }
  }

  fun onCategorySelected(category: String) {
    _uiState.update { it.copy(selectedCategory = category) }
  }

  fun onFormatSelected(format: String) {
    _uiState.update { it.copy(selectedFormat = format) }
  }

  fun onShapeInputChanged(shape: String) {
    _uiState.update { it.copy(shapeInput = shape) }
  }

  fun onImageSelected(uri: Uri?) {
    if (uri == null) return
    viewModelScope.launch {
      val metadata = readImageMetadata(uri)
      _uiState.update { state ->
        val suggestedFormat = when (metadata.extension) {
          "png" -> if (state.selectedFormat.startsWith("PNG")) state.selectedFormat else "PNG (Transparan)"
          "jpg", "jpeg" -> if (state.selectedFormat.startsWith("JPG")) state.selectedFormat else "JPG (High-Res)"
          else -> state.selectedFormat
        }
        state.copy(
          selectedImageUri = uri,
          selectedImageExtension = metadata.extension,
          selectedImageDisplayName = metadata.displayName,
          selectedImageSizeBytes = metadata.sizeBytes,
          selectedFormat = suggestedFormat,
        )
      }
    }
  }

  fun clearSelectedImage() {
    _uiState.update {
      it.copy(
        selectedImageUri = null,
        selectedImageExtension = "png",
        selectedImageDisplayName = "",
        selectedImageSizeBytes = 0L,
      )
    }
  }

  fun onModeFilterSelected(filter: ModeFilter) {
    _uiState.update { it.copy(modeFilter = filter) }
  }

  fun onSearchQueryChanged(query: String) {
    _uiState.update { it.copy(searchQuery = query) }
  }

  fun dismissBanner() {
    _uiState.update { it.copy(statusBanner = null) }
  }

  fun refreshSkins(silentIfEmpty: Boolean = false) {
    val token = _uiState.value.savedToken
    if (token.isBlank()) {
      if (!silentIfEmpty) {
        _uiState.update {
          it.copy(statusBanner = StatusBanner.Error("Masukkan dan simpan Token GitHub (PAT) terlebih dahulu."))
        }
      }
      return
    }

    viewModelScope.launch {
      _uiState.update { it.copy(isLoadingSkins = true) }
      repository.fetchSkins(token).fold(
        onSuccess = { result ->
          _uiState.update {
            it.copy(
              isLoadingSkins = false,
              skins = result.items,
            )
          }
        },
        onFailure = { error ->
          _uiState.update {
            it.copy(
              isLoadingSkins = false,
              statusBanner = StatusBanner.Error(error.message ?: "Gagal memuat skins.json dari GitHub."),
            )
          }
        },
      )
    }
  }

  fun uploadSkin() {
    val state = _uiState.value
    val token = state.savedToken
    if (token.isBlank()) {
      _uiState.update {
        it.copy(
          isTokenSectionExpanded = true,
          statusBanner = StatusBanner.Error("Simpan Token GitHub (PAT) terlebih dahulu sebelum mengunggah."),
        )
      }
      return
    }

    val finalName = state.finalizedSkinName
    if (finalName.isBlank()) {
      _uiState.update {
        it.copy(statusBanner = StatusBanner.Error("Judul Nama Skin wajib diisi (contoh: closed_hihat_bronze)."))
      }
      return
    }

    if (state.shapeInput.trim().isBlank()) {
      _uiState.update {
        it.copy(statusBanner = StatusBanner.Error("Deskripsi bentuk aset (shape) wajib diisi."))
      }
      return
    }

    val imageUri = state.selectedImageUri
    if (imageUri == null) {
      _uiState.update {
        it.copy(statusBanner = StatusBanner.Error("Pilih gambar skin dari galeri terlebih dahulu."))
      }
      return
    }

    viewModelScope.launch {
      _uiState.update {
        it.copy(
          isUploading = true,
          progressMessage = "Membaca file gambar dari perangkat...",
          statusBanner = null,
        )
      }

      val bytesResult = withContext(Dispatchers.IO) {
        runCatching {
          getApplication<Application>().contentResolver.openInputStream(imageUri)?.use { it.readBytes() }
            ?: throw IllegalStateException("Tidak dapat membuka file gambar yang dipilih.")
        }
      }

      val imageBytes = bytesResult.getOrElse { err ->
        _uiState.update {
          it.copy(
            isUploading = false,
            progressMessage = "",
            statusBanner = StatusBanner.Error(err.message ?: "Gagal membaca gambar dari galeri."),
          )
        }
        return@launch
      }

      val result = repository.uploadSkin(
        token = token,
        mode = state.selectedMode,
        category = state.selectedCategory,
        skinName = finalName,
        format = state.selectedFormat,
        shape = state.shapeInput.trim(),
        imageBytes = imageBytes,
        fileExtension = state.effectiveExtension,
        onProgress = { msg ->
          _uiState.update { it.copy(progressMessage = msg) }
        },
      )

      result.fold(
        onSuccess = { updatedSkins ->
          _uiState.update {
            it.copy(
              isUploading = false,
              progressMessage = "",
              skins = updatedSkins,
              skinNameInput = "",
              selectedImageUri = null,
              selectedImageDisplayName = "",
              selectedImageSizeBytes = 0L,
              statusBanner = StatusBanner.Success(
                "Berhasil! \"$finalName\" telah diunggah & ditambahkan ke urutan teratas skins.json."
              ),
            )
          }
        },
        onFailure = { error ->
          _uiState.update {
            it.copy(
              isUploading = false,
              progressMessage = "",
              statusBanner = StatusBanner.Error(error.message ?: "Gagal mengunggah skin ke GitHub."),
            )
          }
        },
      )
    }
  }

  fun requestDelete(item: SkinItem) {
    _uiState.update { it.copy(pendingDeleteItem = item) }
  }

  fun dismissDeleteDialog() {
    _uiState.update { it.copy(pendingDeleteItem = null) }
  }

  fun confirmDelete() {
    val item = _uiState.value.pendingDeleteItem ?: return
    val token = _uiState.value.savedToken
    if (token.isBlank()) {
      _uiState.update {
        it.copy(
          pendingDeleteItem = null,
          statusBanner = StatusBanner.Error("Token GitHub diperlukan untuk menghapus data dari repositori."),
        )
      }
      return
    }

    viewModelScope.launch {
      _uiState.update {
        it.copy(
          pendingDeleteItem = null,
          isDeleting = true,
          progressMessage = "Menghapus ${item.name}...",
          statusBanner = null,
        )
      }

      val result = repository.deleteSkin(
        token = token,
        item = item,
        onProgress = { msg ->
          _uiState.update { it.copy(progressMessage = msg) }
        },
      )

      result.fold(
        onSuccess = { updatedSkins ->
          _uiState.update {
            it.copy(
              isDeleting = false,
              progressMessage = "",
              skins = updatedSkins,
              statusBanner = StatusBanner.Success(
                "\"${item.name}\" dan file gambarnya berhasil dihapus dari repositori."
              ),
            )
          }
        },
        onFailure = { error ->
          _uiState.update {
            it.copy(
              isDeleting = false,
              progressMessage = "",
              statusBanner = StatusBanner.Error(error.message ?: "Gagal menghapus skin dari GitHub."),
            )
          }
        },
      )
    }
  }

  private data class ImageMeta(
    val extension: String,
    val displayName: String,
    val sizeBytes: Long,
  )

  private suspend fun readImageMetadata(uri: Uri): ImageMeta = withContext(Dispatchers.IO) {
    val resolver = getApplication<Application>().contentResolver
    val mimeType = resolver.getType(uri).orEmpty()
    val extFromMime = when {
      mimeType.equals("image/png", ignoreCase = true) -> "png"
      mimeType.equals("image/jpeg", ignoreCase = true) || mimeType.equals("image/jpg", ignoreCase = true) -> "jpg"
      mimeType.equals("image/webp", ignoreCase = true) -> "webp"
      else -> MimeTypeMap.getSingleton().getExtensionFromMimeType(mimeType)?.lowercase().orEmpty()
    }

    var displayName = ""
    var sizeBytes = 0L
    runCatching {
      resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)
        ?.use { cursor ->
          if (cursor.moveToFirst()) {
            val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
            if (nameIdx >= 0) displayName = cursor.getString(nameIdx).orEmpty()
            if (sizeIdx >= 0) sizeBytes = cursor.getLong(sizeIdx)
          }
        }
    }

    val fallbackExt = displayName.substringAfterLast('.', "").lowercase().let { ext ->
      if (ext == "jpeg") "jpg" else ext
    }
    val finalExt = extFromMime.ifBlank { fallbackExt }.ifBlank { "png" }

    ImageMeta(
      extension = finalExt,
      displayName = displayName.ifBlank { "gambar.$finalExt" },
      sizeBytes = sizeBytes,
    )
  }

  companion object {
    fun provideFactory(application: Application): ViewModelProvider.Factory =
      object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
          val moshi = Moshi.Builder()
            .addLast(KotlinJsonAdapterFactory())
            .build()
          val api = GitHubApiService.create(moshi)
          val repository = GitHubSkinsRepository(api, moshi)
          val tokenStore = TokenStore(application)
          return SkinsViewModel(application, tokenStore, repository) as T
        }
      }
  }
}
